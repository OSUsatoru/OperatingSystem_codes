How to compile your code using gcc to create an executable file that must be named movies

gcc --std=gnu99 -o movies_by_year main.c


Example of run program commands by using movies_sample_1.csv

./movies_by_year
