Run this program

./p5testscript RANDOM_PORT1 RANDOM_PORT2 > mytestresults 2>&1